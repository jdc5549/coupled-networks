BaseCBCProject

Originated by Iain Dunning: http://www.iaindunning.com
Shamelessly modified by Ted Ralphs from original versions on

https://github.com/IainNZ/BaseCBCProject

This is a nearly-empty Visual C++ 2010 project with settings ready for use
with the Cbc libraries that come bundled with the COIN-OR installer.

See more: https://projects.coin-or.org/Cbc/wiki/VSSetup

